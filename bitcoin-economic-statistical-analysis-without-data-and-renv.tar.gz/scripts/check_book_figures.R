#!/usr/bin/env Rscript

book_files <- c(
  "02-data-acquisition.qmd",
  "03-price-and-returns.qmd",
  "04-naive-baseline.qmd",
  "05-ar1.qmd"
)

count_matches <- function(text, pattern) {
  matches <- gregexpr(pattern, text, perl = TRUE)[[1L]]
  if (identical(matches[[1L]], -1L)) 0L else length(matches)
}

results <- lapply(book_files, function(path) {
  text <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  data.frame(
    file = path,
    figures = count_matches(text, "#\\| label: fig-"),
    questions = count_matches(text, "figure_question\\("),
    comments = count_matches(text, "figure_comment\\("),
    obsolete_includes = count_matches(text, "reader-figure-comment\\.qmd"),
    stringsAsFactors = FALSE
  )
})
results <- do.call(rbind, results)

if (any(results$figures != results$questions)) {
  stop("Не кожен публічний графік має figure_question().")
}
if (any(results$figures != results$comments)) {
  stop("Не кожен публічний графік має figure_comment().")
}
if (any(results$obsolete_includes != 0L)) {
  stop("Залишилися застарілі include-блоки коментарів.")
}

print(results, row.names = FALSE)
cat("\nСтруктуру публічних графіків перевірено.\n")
